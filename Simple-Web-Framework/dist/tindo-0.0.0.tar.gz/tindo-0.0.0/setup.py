from distutils.core import setup
setup(
    name='tindo',
    author='Gau fung',
    author_email='gaufung@outlook.com',
    packages=['tindo'],
)